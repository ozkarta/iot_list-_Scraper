﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TripleSevenScraper
{
    public partial class Form1 : Form
    {
         
        

        List<string> l1 = new List<string>();
        List<string> l2 = new List<string>();
        List<string> l3 = new List<string>();
        List<string> l4 = new List<string>();


        private Object locker1 = new Object();
        private Object locker2 = new Object();
        private Object locker3 = new Object();
        private Object locker4 = new Object();


        Stopwatch stopWatch1;
        Stopwatch stopWatch2;
        Stopwatch stopWatch3;
        Stopwatch stopWatch4;



        //WebBrowser br1;
        //WebBrowser br2;
        //WebBrowser br3;
        //WebBrowser br4;

        Thread th1;
        Thread th2;
        Thread th3;
        Thread th4;


        int k = 1000;
        string start = "0483380";
        int startInt = 483380+560000+ 13900000;
        //int i = 0;


        int i1, i2, i3, i4;
        string rootURL = "http://app.prmax.co.uk/unsubscribe/";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //i = 0;
            k = 100000;





            i1 = 0;
            i2 = (k/4) ;
            i3 = k/2;
            i4 = (k/4)*3;

            //br1 = new WebBrowser();
            //br2 = new WebBrowser();
            //br3 = new WebBrowser();
            //br4 = new WebBrowser();

            stopWatch1 = new Stopwatch();
            stopWatch2 = new Stopwatch();
            stopWatch3 = new Stopwatch();
            stopWatch4 = new Stopwatch();

            System.IO.StreamWriter file;

            file = new System.IO.StreamWriter("d:\\TripleSeven.txt", false);
            file.WriteLine("                EMAIL LIST FOR 777");
            file.WriteLine("");
            file.WriteLine("");
            file.WriteLine("");
            file.Close();
            

            //WebBrowser br1 = new WebBrowser();
            //WebBrowser br2 = new WebBrowser();
            //WebBrowser br3 = new WebBrowser();
            //WebBrowser br4 = new WebBrowser();


            //br2.DocumentCompleted += br2_documentCompleted;
            //br3.DocumentCompleted += br3_documentCompleted;
            //br4.DocumentCompleted += br4_documentCompleted;


            th1 = new Thread(() => {
                doScpare1();
                Application.Run(); 
            });
            th1.IsBackground = true;
            th1.SetApartmentState(ApartmentState.STA);
            th1.Start();

            th2 = new Thread(() => {
                doScpare2();
                Application.Run();
            });
            th2.IsBackground = true;
            th2.SetApartmentState(ApartmentState.STA);
            th2.Start();

            th3 = new Thread(() => {
                doScpare3();
                Application.Run();
            });
            th3.IsBackground = true;
            th3.SetApartmentState(ApartmentState.STA);
            th3.Start();

            th4 = new Thread(() => {
                doScpare4();
                Application.Run();
            });
            th4.IsBackground = true;
            th4.SetApartmentState(ApartmentState.STA);
            th4.Start();
            //doScpare1();
            // th2 = new Thread(new ThreadStart(doScpare2));
            //th2.Start();

            // th3 = new Thread(new ThreadStart(doScpare3));
            //th3.Start();

            // th4 = new Thread(new ThreadStart(doScpare4));
            //th4.Start();
        }


        public void doScpare1()
        {
            WebBrowser br1 = new WebBrowser();

            int move = 0; 
                stopWatch1.Start();
                move = startInt + i1;
                i1++;
            string currentURL = rootURL + move;

            br1.DocumentCompleted += br1_documentCompleted;
            //Console.WriteLine(currentURL);
            try
            {
                br1.Navigate(currentURL);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public void doScpare2()
        {
            WebBrowser br2 = new WebBrowser();
            int move = 0;
            stopWatch2.Start();
            move = startInt + i2;
            i2++;
            string currentURL = rootURL + move;

            br2.DocumentCompleted += br2_documentCompleted;
            //Console.WriteLine(currentURL);
            try
            {
                br2.Navigate(currentURL);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public void doScpare3()
        {
            WebBrowser br3 = new WebBrowser();
            int move = 0;
            stopWatch3.Start();
            move = startInt + i3;
            i3++;
            string currentURL = rootURL + move;

            br3.DocumentCompleted += br3_documentCompleted;
            //Console.WriteLine(currentURL);
            try
            {
                br3.Navigate(currentURL);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public void doScpare4()
        {
            WebBrowser br4 = new WebBrowser();
            int move = 0;
            stopWatch4.Start();
            move = startInt + i4;
            i4++;
            string currentURL = rootURL + move;

            br4.DocumentCompleted += br4_documentCompleted;
            //Console.WriteLine(currentURL);
            try
            {
                br4.Navigate(currentURL);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }









        private void br1_documentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            completedCustom1(sender);
        }
        private void br2_documentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            completedCustom2(sender);
        }
        private void br3_documentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            completedCustom3(sender);
        }
        private void br4_documentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            completedCustom4(sender);
        }








        private void completedCustom1(object sender)
        {
            WebBrowser navigated = sender as WebBrowser;
            //Console.WriteLine("navigated");


            if (navigated.Document != null)
            {
                HtmlElementCollection elements = navigated.Document.GetElementsByTagName("p");
                if (elements != null)
                {
                    if (elements.Count != 0)
                    {
                        string copied = elements[0].InnerText.ToString();
                        if (copied.Trim() != "")
                        {
                            lock (locker1)
                            {
                                l1.Add(copied.Substring(0, copied.Length - 1));
                                //file.WriteLine(copied.Substring(0, copied.Length - 1));
                            }
                        }
                    }
                }


            }

            if (i1 < k/4)
            {
                int move = startInt + i1;
                i1++;
                string currentURL = rootURL + move;
                //Console.WriteLine(currentURL);
                try
                {
                    navigated.Navigate(currentURL);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
                //file.Close();
                stopWatch1.Stop();
                TimeSpan ts = stopWatch1.Elapsed;
                string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                   ts.Hours, ts.Minutes, ts.Seconds,
                   ts.Milliseconds / 10);
                System.IO.StreamWriter file = new System.IO.StreamWriter("d:\\TripleSeven.txt", true);
                foreach (var s in l1)
                {
                    lock (locker1)
                    {
                        file.WriteLine(s);
                    }
                }
                file.Close();
                Console.WriteLine("RunTime 1 " + elapsedTime);
                th1.Abort();
                
            }


        }




        private void completedCustom2(object sender)
        {
            WebBrowser navigated = sender as WebBrowser;
            //Console.WriteLine("navigated");


            if (navigated.Document != null)
            {
                HtmlElementCollection elements = navigated.Document.GetElementsByTagName("p");
                if (elements != null)
                {
                    if (elements.Count != 0)
                    {
                        string copied = elements[0].InnerText.ToString();
                        if (copied.Trim() != "")
                        {
                            lock (locker2)
                            {
                                l2.Add(copied.Substring(0, copied.Length - 1));
                                //file.WriteLine(copied.Substring(0, copied.Length - 1));
                            }
                        }
                    }
                }


            }

            if (i2 < k/2)
            {
                int move = startInt + i2;
                i2++;
                string currentURL = rootURL + move;
                //Console.WriteLine(currentURL);
                try
                {
                    navigated.Navigate(currentURL);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
                //file.Close();
                stopWatch2.Stop();
                TimeSpan ts = stopWatch2.Elapsed;
                string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                   ts.Hours, ts.Minutes, ts.Seconds,
                   ts.Milliseconds / 10);
                System.IO.StreamWriter file = new System.IO.StreamWriter("d:\\TripleSeven.txt", true);
                foreach (var s in l2)
                {
                    lock (locker2)
                    {
                        file.WriteLine(s);
                    }
                }
                file.Close();
                Console.WriteLine("RunTime 2 " + elapsedTime);
                th2.Abort();
                
            }


        }



        private void completedCustom3(object sender)
        {
            WebBrowser navigated = sender as WebBrowser;
            //Console.WriteLine("navigated");


            if (navigated.Document != null)
            {
                HtmlElementCollection elements = navigated.Document.GetElementsByTagName("p");
                if (elements != null)
                {
                    if (elements.Count != 0)
                    {
                        string copied = elements[0].InnerText.ToString();
                        if (copied.Trim() != "")
                        {
                            lock (locker3)
                            {
                                //file.WriteLine(copied.Substring(0, copied.Length - 1));
                                l3.Add(copied.Substring(0, copied.Length - 1));
                            }
                        }
                    }
                }


            }

            if (i3 < (k/4)*3)
            {
                int move = startInt + i3;
                i3++;
                string currentURL = rootURL + move;
                //Console.WriteLine(currentURL);
                try
                {
                    navigated.Navigate(currentURL);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
               // file.Close();
                stopWatch3.Stop();
                TimeSpan ts = stopWatch3.Elapsed;
                string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                   ts.Hours, ts.Minutes, ts.Seconds,
                   ts.Milliseconds / 10);
                System.IO.StreamWriter file = new System.IO.StreamWriter("d:\\TripleSeven.txt", true);
                foreach (var s in l3)
                {
                    lock (locker3)
                    {
                        file.WriteLine(s);
                    }
                }
                file.Close();
                Console.WriteLine("RunTime 3 " + elapsedTime);
                th3.Abort();
                
            }


        }



        private void completedCustom4(object sender)
        {
            WebBrowser navigated = sender as WebBrowser;
            //Console.WriteLine("navigated");


            if (navigated.Document != null)
            {
                HtmlElementCollection elements = navigated.Document.GetElementsByTagName("p");
                if (elements != null)
                {
                    if (elements.Count != 0)
                    {
                        string copied = elements[0].InnerText.ToString();
                        if (copied.Trim() != "")
                        {
                            lock (locker4)
                            {
                                l4.Add(copied.Substring(0, copied.Length - 1));
                                //file.WriteLine(copied.Substring(0, copied.Length - 1));
                            }
                            
                        }
                    }
                }


            }

            if (i4 < k)
            {
                int move = startInt + i4;
                i4++;
                string currentURL = rootURL + move;
                //Console.WriteLine(currentURL);
                try
                {
                    navigated.Navigate(currentURL);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
                //file.Close();
                stopWatch4.Stop();
                TimeSpan ts = stopWatch4.Elapsed;
                string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                   ts.Hours, ts.Minutes, ts.Seconds,
                   ts.Milliseconds / 10);
                System.IO.StreamWriter file = new System.IO.StreamWriter("d:\\TripleSeven.txt", true);
                foreach (var s in l4)
                {
                    lock (locker4)
                    {
                        file.WriteLine(s);
                    }
                }
                file.Close();
                Console.WriteLine("RunTime 4 " + elapsedTime);
                th4.Abort();
                
            }


        }
    }
}
